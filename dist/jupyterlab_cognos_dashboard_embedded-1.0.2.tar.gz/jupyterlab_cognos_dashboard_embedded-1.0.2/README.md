# jupyterlab-cognos-dashboard-embedded [![Build Status](https://travis.ibm.com/cognitive-class-labs/jupyterlab-cognos-dashboard-embedded.svg?token=xeywPRUyHm9VWQkDxLoo&branch=master)](https://travis.ibm.com/cognitive-class-labs/jupyterlab-cognos-dashboard-embedded)

A JupyterLab extension for creating and viewing Cognos Embedded Dashboards.
